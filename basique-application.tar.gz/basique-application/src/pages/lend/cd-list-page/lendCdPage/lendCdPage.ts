import {Component, OnInit} from "@angular/core";
import {NavParams, ViewController} from "ionic-angular";
import {LocationServices} from "../../../../services/location.services";
import {Cd} from "../../../../models/Cd";

@Component({
  selector: 'page-lend-cd',
  templateUrl: 'lendCdPage.html'
})

export class LendCdPage implements OnInit{

  index: number;
  cd: Cd;
  constructor(public navParams: NavParams, private viewCtrl: ViewController,
              private cdService: LocationServices){}

  ngOnInit(): void {
    this.index = this.navParams.get('index');
    this.cd = this.cdService.cdList[this.index];
  }
  dissmissModal(){
    this.viewCtrl.dismiss();
  }
  onToggleBook(){
    this.cd.isLend = !this.cd.isLend;
  }
}
