import {Component} from "@angular/core";
import {MenuController, ModalController} from "ionic-angular";
import {LocationServices} from "../../../services/location.services";
import {Cd} from "../../../models/Cd";
import {LendCdPage} from "./lendCdPage/lendCdPage";

@Component({
  selector: 'page-cd-list',
  templateUrl: 'cd-list-page.html'
})

export class CdListPage{

  cdList: Cd[];
  constructor(private menuCtrl: MenuController, private locationService: LocationServices,
              private modalCtrl: ModalController){}

  onToggleMenu(){
    this.menuCtrl.open();
  }

  ionViewWillEnter(){
    this.cdList = this.locationService.cdList.slice();
  }

  onLoadBook(index: number) {

    let modal = this.modalCtrl.create(LendCdPage, {index: index});
    modal.present();
  }
}
