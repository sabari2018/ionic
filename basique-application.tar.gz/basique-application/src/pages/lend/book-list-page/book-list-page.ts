import {Component, OnInit} from "@angular/core";
import {MenuController, ModalController} from "ionic-angular";
import {Book} from "../../../models/Book";
import {LocationServices} from "../../../services/location.services";
import {LendBookPage} from "./LendBookPage/lendBookPage";

@Component({
  selector: 'page-book-list',
  templateUrl: 'book-list-page.html'
})

export class BookListPage{

  bookList: Book[];
  constructor(private menuCtrl: MenuController, private locationService: LocationServices,
              private modalCtrl: ModalController){}

  onToggleMenu(){
    this.menuCtrl.open();
  }

  ionViewWillEnter(){
    this.bookList = this.locationService.bookList.slice();
  }

  onLoadBook(index: number) {

    let modal = this.modalCtrl.create(LendBookPage, {index: index});
    modal.present();
  }
}
