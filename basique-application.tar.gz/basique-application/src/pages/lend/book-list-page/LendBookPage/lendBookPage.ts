import {Component, OnInit} from "@angular/core";
import {Book} from "../../../../models/Book";
import {NavParams, ViewController} from "ionic-angular";
import {LocationServices} from "../../../../services/location.services";

@Component({
  selector: 'page-lend-book',
  templateUrl: 'lendBookPage.html'
})

export class LendBookPage implements OnInit{

  index: number;
  book: Book;
  constructor(public navParams: NavParams, private viewCtrl: ViewController,
              private bookService: LocationServices){}

   ngOnInit(): void {
    this.index = this.navParams.get('index');
    this.book = this.bookService.bookList[this.index];
   }
   dissmissModal(){
    this.viewCtrl.dismiss();
   }
   onToggleBook(){
    this.book.isLend = !this.book.isLend;
   }
}
