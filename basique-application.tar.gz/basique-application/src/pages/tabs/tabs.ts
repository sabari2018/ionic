import {Component} from "@angular/core";
import {BookListPage} from "../lend/book-list-page/book-list-page";
import {CdListPage} from "../lend/cd-list-page/cd-list-page";

@Component({
  selector: 'page-tabs',
  templateUrl: 'tabs.html'
})

export class TabsPage {

  bookListPage = BookListPage;
  cdListPage = CdListPage;
}
