import {Book} from "../models/Book";
import {Cd} from "../models/Cd";

export class LocationServices {

  bookList: Book[] = [
    {
      title: 'Soleil des independances',
      author: 'Amadou Kourouma',
      isLend: true
    },
    {
      title: 'Cercle des Tropiques',
      author: 'Aliou NFan Toure',
      isLend: false
    },
    {
      title: 'L\'enfanf noir',
      author: 'Camara Laye',
      isLend: false
    }
  ];

  cdList: Cd[] = [
    {
      title: 'Edition Eyrolle',
      description: [
        'Taille: 512 Mo',
        'Contenu: Documents'
      ],
      isLend: true
    },
    {
      title: 'Album Takana',
      description: [
        'Taille: 700 Mo',
        'Contenu: Musique'
      ],
      isLend: false
    },
    {
      title: 'Image documentaire',
      description: [
        'Taille: 700 Mo',
        'Contenu: Images'
      ],
      isLend: true
    }
  ];
}
