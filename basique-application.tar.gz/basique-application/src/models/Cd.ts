export class Cd {
  description: string[];
  isLend: boolean;

  constructor(public title: string){
    this.isLend = false;
  }
}
