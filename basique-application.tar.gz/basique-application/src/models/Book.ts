export class Book {
  author: string;
  isLend: boolean;

  constructor(public title: string){
    this.isLend = false;
  }
}
